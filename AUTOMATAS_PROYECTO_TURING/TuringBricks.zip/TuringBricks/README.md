# Turing Bricks

Una **máquina de Turing real** construida con bloques de juguete en 3D. Al abrir el programa, la máquina se arma sola, pieza por pieza y con el sonido de cada bloque al encajar. Después puedes darle datos, verla «pensar» y ejecutar cada regla sobre la cinta. Al final muestra el procedimiento completo y la respuesta.

Está hecha 100 % en Python con [Ursina](https://www.ursinaengine.org/) (motor 3D basado en Panda3D). Todas las piezas, el mundo y los sonidos se generan por código.

![Armado de la máquina](capturas/1-armado.png)
![Panel de cálculo](capturas/2-calcular.png)
![Resultado con procedimiento](capturas/3-resultado.png)

---

## 1. Requisitos

- **Windows 10 u 11** (también funciona en macOS y Linux).
- **Python 3.12** desde <https://www.python.org/downloads/>. Durante la instalación marca la casilla **«Add python.exe to PATH»**.
- Una tarjeta gráfica con OpenGL 3.2 o superior. Cualquier PC o laptop de los últimos 10 años la tiene.

## 2. Ejecutar el programa

**Opción fácil:** haz doble clic en **`ejecutar.bat`**. La primera vez crea un entorno e instala lo necesario, lo cual tarda 1 o 2 minutos. Las siguientes veces abre directo.

**Opción manual** (desde una terminal en la carpeta del proyecto):

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Para abrirlo en una ventana de 1600×900: `python main.py --ventana`.

## 3. Crear el ejecutable `.exe`

**Opción A, en tu computadora:** haz doble clic en **`crear_exe.bat`**. Al terminar se abre la carpeta `dist\TuringBricks\`, que contiene **`TuringBricks.exe`**.

- Para compartir el programa, comprime la carpeta **completa** `dist\TuringBricks`. El `.exe` necesita la carpeta `_internal` que está a su lado.
- Algunos antivirus marcan como sospechosos los `.exe` recién creados con PyInstaller. Es un falso positivo conocido: puedes agregar una excepción.

**Opción B, en la nube con GitHub:**

1. Sube el proyecto a un repositorio de GitHub.
2. Abre la pestaña **Actions** y ejecuta **«Crear ejecutable para Windows»**.
3. Descarga el artefacto `TuringBricks-Windows`.

## 4. Cómo se usa

1. **Armado:** al abrir, la máquina se construye pieza por pieza y una tarjeta explica cada parte: base, cinta, cabezal, unidad de control, tabla de reglas y operadores. Puedes pulsar **Saltar** o la tecla Espacio.
2. **Calcular:** en el panel izquierdo elige una categoría y un cálculo, escribe los datos y pulsa **Calcular**.
3. **La máquina piensa:** se encienden las luces, giran los engranajes y la cinta se recarga con tu entrada.
4. **Ejecución:** en cada paso la máquina lee la celda, el cabezal baja a escribir, la cinta se desliza y cambia el estado. La pantalla verde muestra el estado y el tablero muestra la regla δ que se está aplicando.
5. **Resultado:** el panel derecho muestra la respuesta, el número de pasos, los estados usados y las celdas visitadas. También muestra el procedimiento completo en dos vistas:
   - **Procedimiento:** cada regla aplicada.
   - **Configuraciones:** la cinta completa en cada paso, con el estado entre corchetes.

### Controles

| Acción | Cómo |
|---|---|
| Pausar o continuar | Botón **Pausar** o tecla **Espacio** |
| Avanzar un solo paso | Botón **Paso** o **flecha derecha** |
| Cambiar la velocidad | Toca los 10 bloquecitos de colores (el 10 es modo turbo) |
| Ver la respuesta de inmediato | **Saltar al resultado** |
| Girar la cámara | Arrastrar con el **botón derecho** del ratón |
| Acercar o alejar | **Rueda** del ratón |
| Volver a la vista inicial | Botón **Vista** |
| Pantalla completa | **F11** |
| Volver a ver el armado | Botón **Rearmar** |

## 5. Cálculos incluidos

| Categoría | Cálculo | Entrada | Cómo trabaja la máquina |
|---|---|---|---|
| Aritmética | Suma | dos números de 0 a 255 | En binario: resta 1 al segundo y suma 1 al primero hasta que el segundo llega a 0 |
| Aritmética | Resta | dos números de 0 a 255, el primero mayor o igual | En binario: resta 1 a ambos hasta que el sustraendo llega a 0 |
| Aritmética | Multiplicación | dos números de 0 a 9 | En unario: por cada 1 del primero copia todos los 1 del segundo |
| Lenguajes | Palíndromos | cadena de `a` y `b` | Compara y borra el primer y el último símbolo |
| Lenguajes | a^n b^n | cadena de `a` y `b` | Empareja cada `a` (marca X) con una `b` (marca Y) |
| Lenguajes | Paréntesis | cadena de `(` y `)` | Empareja cada `)` con su `(` |
| Utilidades | Incremento | número de 0 a 4095 | Suma 1 en binario con acarreo |
| Utilidades | Complemento | cadena binaria | Invierte cada bit |
| Utilidades | Copiar | cadena binaria | Convierte `w` en `w#w` |

Todas las máquinas se verificaron con miles de casos automáticos. Para repetir esas pruebas:

```bat
python -m tests.test_engine
```

## 6. Crear tus propias máquinas

En la pestaña **Crear máquina** llenas estos datos:

- **Nombre** de la máquina.
- **Estado inicial**, por ejemplo `q0`.
- **Estados finales** separados por coma, por ejemplo `qf`.
- **Blanco**: el símbolo de celda vacía. Por defecto es `_`.
- **Alfabeto Σ**: los símbolos de la entrada, por ejemplo `0,1`.
- **Entrada de prueba**.
- **Reglas**, una por línea:

```
# comentario
q0, 0 -> q0, 1, R
q0, 1 -> q0, 0, R
q0, _ -> qf, _, L
```

Cada regla se lee como **estado, símbolo leído -> nuevo estado, símbolo a escribir, movimiento**. El movimiento es `R` (derecha), `L` (izquierda) o `S` (quedarse); también se aceptan `D`, `I` y `N`. Si para un estado y un símbolo no existe regla, la máquina se detiene y **rechaza**, a menos que esté en un estado final.

Los botones del editor hacen lo siguiente:

- **Probar** valida la máquina y la ejecuta.
- **Guardar** la agrega a *Calcular → Mis máquinas*.
- **Ejemplo** carga una de las máquinas incluidas para que la estudies o la modifiques.

Las máquinas guardadas quedan en `%APPDATA%\TuringBricks\maquinas\` como archivos `.json`.

## 7. Sonidos

Los efectos se generan por síntesis con `generar_sonidos.py`. Por ejemplo, el clic imita los dos golpes de plástico al encajar un bloque. Si quieres el sonido real, graba tus propios bloques y reemplaza `assets/sounds/click_1.wav … click_4.wav` por tus grabaciones en formato `.wav`. La música y los efectos se pueden apagar desde la barra superior.

## 8. Estructura del proyecto

```
TuringBricks/
├── main.py                 punto de entrada
├── app/
│   ├── engine.py           motor de la máquina de Turing (parser, ejecución, trazas)
│   ├── machines.py         biblioteca de máquinas con sus entradas y resultados
│   ├── app.py              controlador: pantallas, ejecución paso a paso, resultados
│   ├── storage.py          guardar y cargar máquinas propias
│   ├── sounds.py           reproducción de sonidos
│   ├── config.py           rutas, colores y fuentes
│   ├── gfx/
│   │   ├── bricks.py       generación procedural de bloques, engranajes, cilindros
│   │   ├── machine3d.py    la máquina de bloques y su animación de armado
│   │   ├── world.py        el mundo animado de fondo
│   │   ├── shader.py       sombreador de plástico (luz, brillo, niebla)
│   │   ├── camera_rig.py   cámara orbital
│   │   └── tween.py        animaciones
│   └── ui/widgets.py       paneles, botones y campos con estilo de bloque
├── assets/                 fuentes, sonidos e ícono
├── tests/test_engine.py    pruebas de todas las máquinas
├── generar_sonidos.py      regenera los efectos de sonido
├── ejecutar.bat            ejecutar con doble clic
├── crear_exe.bat           crear TuringBricks.exe
└── TuringBricks.spec       configuración de PyInstaller
```

## 9. Solución de problemas

- **Pantalla negra o error de OpenGL:** actualiza los controladores de la tarjeta gráfica.
- **No se escucha nada:** revisa los botones *Sonido* y *Música* de la barra superior y el volumen de Windows.
- **Se ve lento:** cierra otras aplicaciones o usa una velocidad de ejecución más alta. La animación es más ligera en el modo turbo.
- **«python no se reconoce como comando»:** reinstala Python y marca «Add python.exe to PATH».

## 10. Créditos y licencias

- Motor 3D: Ursina y Panda3D.
- Fuentes Fredoka, Nunito y JetBrains Mono, bajo la licencia SIL Open Font License. Los archivos de licencia están en `assets/fonts`.
- Proyecto educativo inspirado en los bloques de construcción de juguete. No está afiliado ni respaldado por ninguna marca comercial.
